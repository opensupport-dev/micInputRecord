#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <termios.h>
#include "/usr/include/alsa/asoundlib.h"

// smapling 하여 버퍼에 저장하는 recording 함수
int record_sound(unsigned char *ap_rec_buffer)
{	
	snd_pcm_t *p_capture_handle;    // sound 핸들
	snd_pcm_hw_params_t *p_hw_params; // sound 핸들에 적용할 파라메터
	unsigned int freq = 192000;  // 192Khz 샘플링 frequency 지정

        // mic입력의 sampling frequency로 버퍼에 저장하기 위해 sound핸들 open
        // 사운드 장치 중 "plughw:1,0"(card 1, device 0)장치를 녹음(capture) 모드로 open함.   
	if(snd_pcm_open(&p_capture_handle, "plughw:1,0", SND_PCM_STREAM_CAPTURE,0)<0){
      		perror("Cound not open output audio dev");
      		return 0;
	}	   
        
        //핸들에 적용할 파라메터의 메모리 할당         
	snd_pcm_hw_params_malloc (&p_hw_params);

        // 설정 값을 저장할 메모리에 기본(default) 값을 설정함   
	snd_pcm_hw_params_any (p_capture_handle, p_hw_params);	// set default value

	// 이 장치를 사용하여 send_pcm_readi 또는 send_pcm_writei 함수를 사용하 수 있도혹 함
	snd_pcm_hw_params_set_access (p_capture_handle, p_hw_params, SND_PCM_ACCESS_RW_INTERLEAVED);

	//샘플링 레이트는 부호를 고려하여 2바이트(16qlxm)로 설정하고 바이트 정렬방식은 little endian으로 세팅함
	snd_pcm_hw_params_set_format (p_capture_handle, p_hw_params, (snd_pcm_format_t)SND_PCM_FORMAT_S16_LE);  // signed 16 bits, little endian
	
        // sampling 주기는 192Khz로 함
	snd_pcm_hw_params_set_rate_near (p_capture_handle, p_hw_params, &freq, 0);
	
	// 모노 채널로 세팅함 
	snd_pcm_hw_params_set_channels (p_capture_handle, p_hw_params, 1); // 1 is Mono

	// 녹음 시 사용할 기준 값들을 저장한 p_hw_params를 녹음 장치에 정보 설정
        snd_pcm_hw_params (p_capture_handle, p_hw_params);

	// 녹음 장치에 설정한 기준 값의 메모리를 제거함
	snd_pcm_hw_params_free (p_hw_params);
	
	printf("\tStarted to record for 341ms...\n"); 
	
	// 녹음 시작
       	snd_pcm_prepare (p_capture_handle);

        // 65536 개의 샘플링을 함 (중요:참고로 65536 바이트를 의미하는 것이 아님)
	snd_pcm_readi (p_capture_handle, ap_rec_buffer, 65536); //

	printf("\tFinished to record!\n");

	// 녹음 중지
	snd_pcm_drop(p_capture_handle);

        // 녹음 장치 닫기 
	snd_pcm_close (p_capture_handle);
	
	return 1;
}

// main()에 호출한 스레드 함수
void* thread_routine(void *arg){
        char *rfname = (char*)arg; //argument로 파일이름 스레드로 받아옴
        FILE *p_file;
        pthread_t tid;
 
        tid = pthread_self();
 
        int i=0;
        printf("\tThread tid:%x\n",(unsigned int)tid); // 스레드의 tid 표시함.
        //printf("\tThread file name: %s\n", rfname);

        p_file = fopen(rfname, "wb"); // main()에서 입력된 파일이름으로 파일 생성.

        /* 테스트 코드, 수행 안됨.
        while(i < 5){
                printf("\tnew thread:%d\n",i);
                i++;
                sleep(1);
        }*/

        unsigned char rec_buffer[65536*2];  // 실제 필요한 버퍼 사이즈: 2bytes * 19200KHz * 0.341 msec => 131072 bytes.
        
	if(record_sound(rec_buffer) == 1) { // samplaing 하는 함수 실행.
                fwrite((char *)rec_buffer, 1, sizeof(rec_buffer), p_file); // sampling된 버퍼를 파일로 저장.
                fclose(p_file);
                printf("\tFinished to save the file (%s) !\n", rfname );

        }else{
                // Do nothing here.
        }

        pthread_exit(NULL);
        
}
 
// "micInput" 실행 시 실행 방법 표시함.
void usage(){
        printf("[Error] Require options as belows.\n");
        printf("Recording example: ./micInput -r sound.wav\n");
}

// 에러를 출력하는 매크로 함수
#define handle_error_en(en, msg) \
        do { errno = en; perror(msg); exit(EXIT_FAILURE); } while (0)

//main() 함수
int main(int argc, char *argv[]){
        int stack_size;
        int s, opt;
        pthread_t thread;
        pthread_attr_t attr;

	// "micInput" 명령 실행 시 2개의 argument 가 필요함.
        if (argc != 3){ 
                usage();
                exit(EXIT_FAILURE);        
        }

        int mode;
        char *fname;

        // 2번째 argument가 저장하려는 파일 이름   
        if(argv[1][1] == 'r'){
                mode = 0; // Read:0
                fname =  &argv[2][0];
                //printf("Main file name: %s\n", fname);             
        }else{
                usage();
                exit(EXIT_FAILURE);
        }

        
	// 스레드 생성 시 필요한 attribute 초기화
        s = pthread_attr_init(&attr);
        if(s != 0 )
                handle_error_en(s, "pthread_attr_init");

        // 스레드 생성
        s = pthread_create(&thread,&attr,thread_routine, (void *)fname);
        if(s != 0)
                handle_error_en(s, "pthread_create");

        // 스레드 생성 후 attribute 제거 
        s = pthread_attr_destroy(&attr);
        if (s != 0)
                handle_error_en(s, "pthread_attr_destroy");
        
        int i=0;
        // Main()의 tid 출력
        printf("Main tid:%x\n", (unsigned int)pthread_self());

        //테스트 코드, 수행 안됨.
        while(false){
                printf("main:%d\n",i);
                i++;
                sleep(1);
        }
        
        
        // 스레드 join함
        pthread_join(thread, NULL);
        
        exit(EXIT_SUCCESS);

}
